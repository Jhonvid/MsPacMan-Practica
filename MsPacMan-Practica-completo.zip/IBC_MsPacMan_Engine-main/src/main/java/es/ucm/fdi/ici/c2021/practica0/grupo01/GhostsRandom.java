package es.ucm.fdi.ici.c2021.practica0.grupo01;

import java.util.EnumMap;
import java.util.Random;

import pacman.controllers.GhostController;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/** Cada fantasma toma una dirección legal aleatoria cuando necesita decidir. */
public final class GhostsRandom extends GhostController {

    private final Random random = new Random();

    @Override
    public EnumMap<GHOST, MOVE> getMove(Game game, long timeDue) {
        EnumMap<GHOST, MOVE> moves = new EnumMap<GHOST, MOVE>(GHOST.class);

        for (GHOST ghost : GHOST.values()) {
            if (Boolean.TRUE.equals(game.doesGhostRequireAction(ghost))) {
                moves.put(ghost, ControllerUtils.randomMove(
                        game,
                        game.getGhostCurrentNodeIndex(ghost),
                        game.getGhostLastMoveMade(ghost),
                        random));
            }
        }

        return moves;
    }
}
