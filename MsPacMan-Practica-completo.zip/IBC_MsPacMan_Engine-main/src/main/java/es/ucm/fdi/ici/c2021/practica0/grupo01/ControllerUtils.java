package es.ucm.fdi.ici.c2021.practica0.grupo01;

import java.util.Random;

import pacman.game.Constants.DM;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/** Utilidades compartidas por los controladores de la práctica. */
final class ControllerUtils {

    private static final MOVE[] NO_MOVES = new MOVE[0];

    private ControllerUtils() {
    }

    static MOVE safeLastMove(MOVE lastMove) {
        return lastMove == null ? MOVE.NEUTRAL : lastMove;
    }

    static boolean isValidNode(Game game, int nodeIndex) {
        if (game == null || nodeIndex < 0) {
            return false;
        }

        try {
            return game.isNodeObservable(nodeIndex);
        } catch (RuntimeException e) {
            return false;
        }
    }

    static MOVE[] getPossibleMoves(Game game, int nodeIndex, MOVE lastMove) {
        if (!isValidNode(game, nodeIndex)) {
            return NO_MOVES;
        }

        try {
            MOVE[] moves = game.getPossibleMoves(nodeIndex, safeLastMove(lastMove));
            return moves == null ? NO_MOVES : moves;
        } catch (RuntimeException e) {
            return NO_MOVES;
        }
    }

    static MOVE randomMove(Game game, int nodeIndex, MOVE lastMove, Random random) {
        MOVE[] possibleMoves = getPossibleMoves(game, nodeIndex, lastMove);
        if (possibleMoves.length == 0) {
            return MOVE.NEUTRAL;
        }

        return possibleMoves[random.nextInt(possibleMoves.length)];
    }

    static boolean isLegalMove(Game game, int nodeIndex, MOVE move, MOVE lastMove) {
        if (move == null) {
            return false;
        }

        for (MOVE possibleMove : getPossibleMoves(game, nodeIndex, lastMove)) {
            if (move == possibleMove) {
                return true;
            }
        }
        return false;
    }

    static MOVE approximateTowards(Game game, int fromNode, int targetNode, MOVE lastMove) {
        if (!isValidNode(game, fromNode) || !isValidNode(game, targetNode)) {
            return MOVE.NEUTRAL;
        }

        try {
            return game.getApproximateNextMoveTowardsTarget(
                    fromNode, targetNode, safeLastMove(lastMove), DM.PATH);
        } catch (RuntimeException e) {
            return MOVE.NEUTRAL;
        }
    }

    static MOVE towards(Game game, int fromNode, int targetNode, MOVE lastMove) {
        if (!isValidNode(game, fromNode) || !isValidNode(game, targetNode)) {
            return MOVE.NEUTRAL;
        }

        try {
            return game.getNextMoveTowardsTarget(
                    fromNode, targetNode, safeLastMove(lastMove), DM.PATH);
        } catch (RuntimeException e) {
            return MOVE.NEUTRAL;
        }
    }

    static MOVE away(Game game, int fromNode, int targetNode, MOVE lastMove) {
        if (!isValidNode(game, fromNode) || !isValidNode(game, targetNode)) {
            return MOVE.NEUTRAL;
        }

        try {
            return game.getNextMoveAwayFromTarget(
                    fromNode, targetNode, safeLastMove(lastMove), DM.PATH);
        } catch (RuntimeException e) {
            return MOVE.NEUTRAL;
        }
    }

    static int pathDistance(Game game, int fromNode, int targetNode, MOVE lastMove) {
        if (!isValidNode(game, fromNode) || !isValidNode(game, targetNode)) {
            return Integer.MAX_VALUE;
        }

        try {
            return Math.max(0, game.getShortestPathDistance(
                    fromNode, targetNode, safeLastMove(lastMove)));
        } catch (RuntimeException e) {
            return Integer.MAX_VALUE;
        }
    }

    static int pathDistance(Game game, int fromNode, int targetNode) {
        if (!isValidNode(game, fromNode) || !isValidNode(game, targetNode)) {
            return Integer.MAX_VALUE;
        }

        try {
            return Math.max(0, game.getShortestPathDistance(fromNode, targetNode));
        } catch (RuntimeException e) {
            return Integer.MAX_VALUE;
        }
    }

    static int neighbouringNode(Game game, int nodeIndex, MOVE move) {
        if (!isValidNode(game, nodeIndex) || move == null) {
            return -1;
        }

        try {
            return game.getNeighbour(nodeIndex, move);
        } catch (RuntimeException e) {
            return -1;
        }
    }

    static boolean isInLair(Game game, pacman.game.Constants.GHOST ghost) {
        try {
            return game.getGhostLairTime(ghost) > 0;
        } catch (RuntimeException e) {
            return false;
        }
    }
}
