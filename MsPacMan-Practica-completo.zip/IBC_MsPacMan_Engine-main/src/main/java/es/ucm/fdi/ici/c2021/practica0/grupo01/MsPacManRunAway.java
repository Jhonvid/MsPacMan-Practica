package es.ucm.fdi.ici.c2021.practica0.grupo01;

import java.util.Random;

import pacman.controllers.PacmanController;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/** Ms. Pac-Man huye del fantasma activo más cercano y, si no existe, busca pills. */
public final class MsPacManRunAway extends PacmanController {

    private final Random random = new Random();

    @Override
    public MOVE getMove(Game game, long timeDue) {
        int pacmanNode = game.getPacmanCurrentNodeIndex();
        MOVE lastMove = game.getPacmanLastMoveMade();

        if (!ControllerUtils.isValidNode(game, pacmanNode)) {
            return MOVE.NEUTRAL;
        }

        int nearestGhost = -1;
        int nearestGhostDistance = Integer.MAX_VALUE;

        for (GHOST ghost : GHOST.values()) {
            if (ControllerUtils.isInLair(game, ghost)) {
                continue;
            }

            int ghostNode = game.getGhostCurrentNodeIndex(ghost);
            if (!ControllerUtils.isValidNode(game, ghostNode)) {
                continue;
            }

            int distance = ControllerUtils.pathDistance(
                    game, pacmanNode, ghostNode, lastMove);
            if (distance < nearestGhostDistance) {
                nearestGhostDistance = distance;
                nearestGhost = ghostNode;
            }
        }

        if (nearestGhost >= 0) {
            MOVE move = ControllerUtils.away(
                    game, pacmanNode, nearestGhost, lastMove);
            if (ControllerUtils.isLegalMove(game, pacmanNode, move, lastMove)) {
                return move;
            }

            move = chooseFarthestMove(game, pacmanNode, nearestGhost, lastMove);
            if (move != MOVE.NEUTRAL) {
                return move;
            }
        }

        int nearestPill = findNearestActivePill(game, pacmanNode, lastMove);
        if (nearestPill >= 0) {
            MOVE move = ControllerUtils.towards(game, pacmanNode, nearestPill, lastMove);
            if (ControllerUtils.isLegalMove(game, pacmanNode, move, lastMove)) {
                return move;
            }
        }

        return ControllerUtils.randomMove(game, pacmanNode, lastMove, random);
    }

    private MOVE chooseFarthestMove(Game game, int fromNode, int targetNode, MOVE lastMove) {
        MOVE bestMove = MOVE.NEUTRAL;
        int bestDistance = Integer.MIN_VALUE;

        for (MOVE move : ControllerUtils.getPossibleMoves(game, fromNode, lastMove)) {
            int neighbour = ControllerUtils.neighbouringNode(game, fromNode, move);
            if (neighbour < 0) {
                continue;
            }

            int distance = ControllerUtils.pathDistance(game, neighbour, targetNode);
            if (distance > bestDistance) {
                bestDistance = distance;
                bestMove = move;
            }
        }

        return bestMove;
    }

    private int findNearestActivePill(Game game, int pacmanNode, MOVE lastMove) {
        int bestTarget = -1;
        int bestDistance = Integer.MAX_VALUE;

        int[] pills = game.getActivePillsIndices();
        int[] powerPills = game.getActivePowerPillsIndices();

        if (pills != null) {
            for (int target : pills) {
                bestTarget = closerTarget(game, pacmanNode, lastMove,
                        target, bestTarget, bestDistance);
                bestDistance = distanceToTarget(game, pacmanNode, lastMove, bestTarget);
            }
        }
        if (powerPills != null) {
            for (int target : powerPills) {
                bestTarget = closerTarget(game, pacmanNode, lastMove,
                        target, bestTarget, bestDistance);
                bestDistance = distanceToTarget(game, pacmanNode, lastMove, bestTarget);
            }
        }

        return bestTarget;
    }

    private int closerTarget(Game game, int fromNode, MOVE lastMove,
            int candidate, int currentTarget, int currentDistance) {
        if (!ControllerUtils.isValidNode(game, candidate)) {
            return currentTarget;
        }

        int candidateDistance = ControllerUtils.pathDistance(
                game, fromNode, candidate, lastMove);
        return candidateDistance < currentDistance ? candidate : currentTarget;
    }

    private int distanceToTarget(Game game, int fromNode, MOVE lastMove, int target) {
        return target < 0 ? Integer.MAX_VALUE
                : ControllerUtils.pathDistance(game, fromNode, target, lastMove);
    }
}
