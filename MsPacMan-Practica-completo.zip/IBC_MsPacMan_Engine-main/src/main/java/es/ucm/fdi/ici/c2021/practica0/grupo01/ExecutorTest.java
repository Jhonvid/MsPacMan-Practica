package es.ucm.fdi.ici.c2021.practica0.grupo01;

import pacman.Executor;
import pacman.controllers.GhostController;
import pacman.controllers.PacmanController;

/** Punto de entrada para probar la pareja principal de la práctica. */
public final class ExecutorTest {

    private ExecutorTest() {
    }

    public static void main(String[] args) {
        Executor executor = new Executor.Builder()
                .setTickLimit(4000)
                .setGhostPO(false)
                .setPacmanPO(false)
                .setGhostsMessage(false)
                .setVisual(true)
                .setScaleFactor(3.0)
                .setPacmanPOvisual(false)
                .build();

        PacmanController pacMan = new MyFirstMsPacMan();
        GhostController ghosts = new MyFirstGhosts();

        System.out.println("Ejecutando MyFirstMsPacMan contra MyFirstGhosts");
        System.out.println("Puntuación: " + executor.runGame(pacMan, ghosts, 50));
    }
}
