package es.ucm.fdi.ici.c2021.practica0.grupo01;

import java.util.Random;

import pacman.controllers.PacmanController;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/** Ms. Pac-Man selecciona aleatoriamente una dirección legal. */
public final class MsPacManRandom extends PacmanController {

    private final Random random = new Random();

    @Override
    public MOVE getMove(Game game, long timeDue) {
        return ControllerUtils.randomMove(
                game,
                game.getPacmanCurrentNodeIndex(),
                game.getPacmanLastMoveMade(),
                random);
    }
}
