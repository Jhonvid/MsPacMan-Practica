package es.ucm.fdi.ici.c2021.practica0.grupo01;

import java.util.EnumMap;
import java.util.Random;

import pacman.controllers.GhostController;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/** Fantasmas que huyen en peligro y persiguen a Ms. Pac-Man en otro caso. */
public final class MyFirstGhosts extends GhostController {

    private static final int POWER_PILL_DANGER_DISTANCE = 15;
    private static final double CHASE_PROBABILITY = 0.90;

    private final Random random = new Random();

    @Override
    public EnumMap<GHOST, MOVE> getMove(Game game, long timeDue) {
        EnumMap<GHOST, MOVE> moves = new EnumMap<GHOST, MOVE>(GHOST.class);
        int pacmanNode = game.getPacmanCurrentNodeIndex();
        MOVE pacmanLastMove = game.getPacmanLastMoveMade();

        for (GHOST ghost : GHOST.values()) {
            if (!Boolean.TRUE.equals(game.doesGhostRequireAction(ghost))
                    || ControllerUtils.isInLair(game, ghost)) {
                continue;
            }

            int ghostNode = game.getGhostCurrentNodeIndex(ghost);
            MOVE ghostLastMove = game.getGhostLastMoveMade(ghost);
            if (!ControllerUtils.isValidNode(game, ghostNode)) {
                continue;
            }

            MOVE move = MOVE.NEUTRAL;
            boolean pacmanVisible = ControllerUtils.isValidNode(game, pacmanNode);

            if (pacmanVisible && game.getGhostEdibleTime(ghost) > 0) {
                move = ControllerUtils.away(
                        game, ghostNode, pacmanNode, ghostLastMove);
            } else if (pacmanVisible
                    && isPacmanNearActivePowerPill(game, pacmanNode, pacmanLastMove)) {
                move = ControllerUtils.away(
                        game, ghostNode, pacmanNode, ghostLastMove);
            } else if (pacmanVisible && random.nextDouble() < CHASE_PROBABILITY) {
                move = ControllerUtils.towards(
                        game, ghostNode, pacmanNode, ghostLastMove);
            }

            if (!ControllerUtils.isLegalMove(game, ghostNode, move, ghostLastMove)) {
                move = ControllerUtils.randomMove(
                        game, ghostNode, ghostLastMove, random);
            }

            moves.put(ghost, move);
        }

        return moves;
    }

    private boolean isPacmanNearActivePowerPill(Game game, int pacmanNode, MOVE lastMove) {
        int[] powerPills = game.getActivePowerPillsIndices();
        if (powerPills == null) {
            return false;
        }

        for (int powerPill : powerPills) {
            if (ControllerUtils.isValidNode(game, powerPill)
                    && ControllerUtils.pathDistance(game, pacmanNode, powerPill, lastMove)
                    <= POWER_PILL_DANGER_DISTANCE) {
                return true;
            }
        }

        return false;
    }
}
