package es.ucm.fdi.ici.c2021.practica0.grupo01;

import java.util.Random;

import pacman.controllers.PacmanController;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/** Controlador de Ms. Pac-Man con prioridades de ataque, defensa y búsqueda de pills. */
public final class MyFirstMsPacMan extends PacmanController {

    private static final int DANGER_DISTANCE = 20;

    private final Random random = new Random();

    @Override
    public MOVE getMove(Game game, long timeDue) {
        int pacmanNode = game.getPacmanCurrentNodeIndex();
        MOVE lastMove = game.getPacmanLastMoveMade();

        if (!ControllerUtils.isValidNode(game, pacmanNode)) {
            return MOVE.NEUTRAL;
        }

        Target edibleTarget = findReachableEdibleGhost(game, pacmanNode, lastMove);
        if (edibleTarget != null) {
            MOVE move = ControllerUtils.towards(
                    game, pacmanNode, edibleTarget.node, lastMove);
            if (!ControllerUtils.isLegalMove(game, pacmanNode, move, lastMove)) {
                move = ControllerUtils.approximateTowards(
                        game, pacmanNode, edibleTarget.node, lastMove);
            }
            if (ControllerUtils.isLegalMove(game, pacmanNode, move, lastMove)) {
                return move;
            }
        }

        DangerousGhosts dangerousGhosts = findDangerousGhosts(game, pacmanNode, lastMove);
        if (dangerousGhosts.count > 0
                && dangerousGhosts.nearestDistance <= DANGER_DISTANCE) {
            MOVE move = chooseSafestMove(
                    game, pacmanNode, lastMove, dangerousGhosts);
            if (move != MOVE.NEUTRAL) {
                return move;
            }

            move = ControllerUtils.away(
                    game, pacmanNode, dangerousGhosts.nearestNode, lastMove);
            if (ControllerUtils.isLegalMove(game, pacmanNode, move, lastMove)) {
                return move;
            }
        }

        int nearestPill = findNearestActivePill(game, pacmanNode, lastMove);
        if (nearestPill >= 0) {
            MOVE move = ControllerUtils.towards(game, pacmanNode, nearestPill, lastMove);
            if (!ControllerUtils.isLegalMove(game, pacmanNode, move, lastMove)) {
                move = ControllerUtils.approximateTowards(
                        game, pacmanNode, nearestPill, lastMove);
            }
            if (ControllerUtils.isLegalMove(game, pacmanNode, move, lastMove)) {
                return move;
            }
        }

        return ControllerUtils.randomMove(game, pacmanNode, lastMove, random);
    }

    private Target findReachableEdibleGhost(Game game, int pacmanNode, MOVE lastMove) {
        Target best = null;

        for (GHOST ghost : GHOST.values()) {
            if (ControllerUtils.isInLair(game, ghost)
                    || game.getGhostEdibleTime(ghost) <= 0) {
                continue;
            }

            int ghostNode = game.getGhostCurrentNodeIndex(ghost);
            if (!ControllerUtils.isValidNode(game, ghostNode)) {
                continue;
            }

            int distance = ControllerUtils.pathDistance(
                    game, pacmanNode, ghostNode, lastMove);
            if (distance <= game.getGhostEdibleTime(ghost)
                    && (best == null || distance < best.distance)) {
                best = new Target(ghostNode, distance);
            }
        }

        return best;
    }

    private DangerousGhosts findDangerousGhosts(Game game, int pacmanNode, MOVE lastMove) {
        int[] nodes = new int[GHOST.values().length];
        int count = 0;
        int nearestNode = -1;
        int nearestDistance = Integer.MAX_VALUE;

        for (GHOST ghost : GHOST.values()) {
            if (ControllerUtils.isInLair(game, ghost)
                    || game.getGhostEdibleTime(ghost) > 0) {
                continue;
            }

            int ghostNode = game.getGhostCurrentNodeIndex(ghost);
            if (!ControllerUtils.isValidNode(game, ghostNode)) {
                continue;
            }

            int distance = ControllerUtils.pathDistance(
                    game, pacmanNode, ghostNode, lastMove);
            nodes[count++] = ghostNode;
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearestNode = ghostNode;
            }
        }

        return new DangerousGhosts(nodes, count, nearestNode, nearestDistance);
    }

    private MOVE chooseSafestMove(Game game, int pacmanNode, MOVE lastMove,
            DangerousGhosts dangerousGhosts) {
        MOVE bestMove = MOVE.NEUTRAL;
        int bestMinimumDistance = Integer.MIN_VALUE;

        for (MOVE move : ControllerUtils.getPossibleMoves(game, pacmanNode, lastMove)) {
            int neighbour = ControllerUtils.neighbouringNode(game, pacmanNode, move);
            if (neighbour < 0) {
                continue;
            }

            int minimumDistance = Integer.MAX_VALUE;
            for (int index = 0; index < dangerousGhosts.count; index++) {
                minimumDistance = Math.min(minimumDistance,
                        ControllerUtils.pathDistance(
                                game, neighbour, dangerousGhosts.nodes[index]));
            }

            if (minimumDistance > bestMinimumDistance) {
                bestMinimumDistance = minimumDistance;
                bestMove = move;
            }
        }

        return bestMove;
    }

    private int findNearestActivePill(Game game, int pacmanNode, MOVE lastMove) {
        int bestTarget = -1;
        int bestDistance = Integer.MAX_VALUE;
        int[] pills = game.getActivePillsIndices();
        int[] powerPills = game.getActivePowerPillsIndices();

        if (pills != null) {
            for (int target : pills) {
                bestTarget = chooseCloserTarget(
                        game, pacmanNode, lastMove, target, bestTarget, bestDistance);
                bestDistance = distanceToTarget(game, pacmanNode, lastMove, bestTarget);
            }
        }
        if (powerPills != null) {
            for (int target : powerPills) {
                bestTarget = chooseCloserTarget(
                        game, pacmanNode, lastMove, target, bestTarget, bestDistance);
                bestDistance = distanceToTarget(game, pacmanNode, lastMove, bestTarget);
            }
        }
        return bestTarget;
    }

    private int chooseCloserTarget(Game game, int fromNode, MOVE lastMove,
            int candidate, int currentTarget, int currentDistance) {
        if (!ControllerUtils.isValidNode(game, candidate)) {
            return currentTarget;
        }

        int distance = ControllerUtils.pathDistance(game, fromNode, candidate, lastMove);
        return distance < currentDistance ? candidate : currentTarget;
    }

    private int distanceToTarget(Game game, int fromNode, MOVE lastMove, int target) {
        return target < 0 ? Integer.MAX_VALUE
                : ControllerUtils.pathDistance(game, fromNode, target, lastMove);
    }

    private static final class Target {
        private final int node;
        private final int distance;

        private Target(int node, int distance) {
            this.node = node;
            this.distance = distance;
        }
    }

    private static final class DangerousGhosts {
        private final int[] nodes;
        private final int count;
        private final int nearestNode;
        private final int nearestDistance;

        private DangerousGhosts(int[] nodes, int count, int nearestNode, int nearestDistance) {
            this.nodes = nodes;
            this.count = count;
            this.nearestNode = nearestNode;
            this.nearestDistance = nearestDistance;
        }
    }
}
