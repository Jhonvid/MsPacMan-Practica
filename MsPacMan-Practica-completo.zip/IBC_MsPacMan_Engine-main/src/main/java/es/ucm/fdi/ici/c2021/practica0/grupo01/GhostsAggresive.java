package es.ucm.fdi.ici.c2021.practica0.grupo01;

import java.util.EnumMap;

import pacman.controllers.GhostController;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/** Fantasmas que persiguen a Ms. Pac-Man usando distancia PATH. */
public final class GhostsAggresive extends GhostController {

    @Override
    public EnumMap<GHOST, MOVE> getMove(Game game, long timeDue) {
        EnumMap<GHOST, MOVE> moves = new EnumMap<GHOST, MOVE>(GHOST.class);
        int pacmanNode = game.getPacmanCurrentNodeIndex();

        for (GHOST ghost : GHOST.values()) {
            if (!Boolean.TRUE.equals(game.doesGhostRequireAction(ghost))) {
                continue;
            }

            int ghostNode = game.getGhostCurrentNodeIndex(ghost);
            MOVE lastMove = game.getGhostLastMoveMade(ghost);
            MOVE move = MOVE.NEUTRAL;

            if (!ControllerUtils.isInLair(game, ghost)
                    && ControllerUtils.isValidNode(game, ghostNode)
                    && ControllerUtils.isValidNode(game, pacmanNode)) {
                move = ControllerUtils.approximateTowards(
                        game, ghostNode, pacmanNode, lastMove);

                if (!ControllerUtils.isLegalMove(game, ghostNode, move, lastMove)) {
                    move = ControllerUtils.towards(
                            game, ghostNode, pacmanNode, lastMove);
                }

                if (!ControllerUtils.isLegalMove(game, ghostNode, move, lastMove)) {
                    move = MOVE.NEUTRAL;
                }
            }

            moves.put(ghost, move);
        }

        return moves;
    }
}
